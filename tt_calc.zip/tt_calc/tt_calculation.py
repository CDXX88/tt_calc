# Given values
source_bid = float(input("Source Bid = "))
source_ask = float(input("Source Ask = "))
target_bid = float(input("Target Bid = "))
target_ask = float(input("Target Ask = "))
NumberOfSpreadsToCompare = int(input("NumberOfSpreadsToCompare = "))

# Calculate differences
bid_diff = round(abs(source_bid - target_bid), 4)
ask_diff = round(abs(source_ask - target_ask), 4)

# Calculate target spread
target_spread = round(((target_ask - target_bid) * NumberOfSpreadsToCompare), 4)

# Check conditions
if bid_diff >= target_spread or ask_diff >= target_spread:
    notification = True
else:
    notification = False

# Print result
print("Bid Difference:", bid_diff)
print("Ask Difference:", ask_diff)
print("Target Spread * NumberOfSpreadsToCompare:", target_spread)
print("Notification:", notification)

# Code out
input("Press Enter to exit...")